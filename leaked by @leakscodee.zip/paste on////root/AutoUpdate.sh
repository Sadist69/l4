cd /media/ && python3 SCRAPE.py
